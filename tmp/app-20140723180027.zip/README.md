# Out of Office App

This app will allow agents to manage their vacation status, reassigning agent tickets to their group if updated during the vacation. 

Please submit bug reports to [the issues page](https://github.com/ZendeskES/out-of-office-app/issues). Pull requests are welcome.

### Screenshot(s):
![](http://cl.ly/WOQz/Screen%20Shot%202014-07-03%20at%207.24.11%20PM.png)
